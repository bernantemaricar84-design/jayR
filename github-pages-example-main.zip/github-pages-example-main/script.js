document.addEventListener("DOMContentLoaded", () => {
  console.log("Portfolio Loaded Successfully!");
  alert("Welcome to Jayrome Malaubang's Portfolio!");
});